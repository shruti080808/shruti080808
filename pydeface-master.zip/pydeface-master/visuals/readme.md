Logo is modified from:
<http://nipy.org/workshops/2017-03-boston/lectures/intro/nipype_logo.svg>.
